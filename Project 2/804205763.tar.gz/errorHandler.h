/*
Jonathan Woong
804205763
CS118
Project 2
*/

////////// ERROR HANDLING CLASS //////////
class errorHandler {
public:
	void print(int errorNumber);
private:
};
